<?php 
    include("header.php");
    session_start();
    
?>
<!DOCTYPE html>
<html>
    <head>
        <title>
                NAVIGATION
        </title>

        <style>
            .card-body.img:hover{
                transform: scale(1.25,1.25);
            }
          
        </style>
        <link rel="stylesheet" href="bootstrap.css">
        <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>



    </head>
    <body>
      
        <div class="container">
            <nav class="navbar navbar-expand-lg bg-success fixed-top">
            <b style="padding-left: 550px;"><h1>VEGTABLES</h1></b>
            <ul class="navbar-nav">
                <li class="nav-item" class="cart" id="cart">
                    <?php 
                    $count=0;
                    if(isset($_SESSION['cart'])){
                        $count=count($_SESSION['cart']);
                    }
                    ?>
                    <b class="btn btn-outline-success"><i class="fa fa-shopping-cart" style="font-size:20px;color:rgb(15, 10, 10)"><a href="mycart.php">MY CART(<b style="color:red"><?php echo $count;?></b>)</a> </i></b>
                    <div id="title"></div>
                </li>
                </ul>
               
            </nav>
           
        </div>

        <!--cards-->
         <div class="conatainer"><br><br><br><br>
            <div  class="row" >
                <div class="col-md-2">
                   
                        
                    </div>
                </div>
                
                <div class="col-md-2">
                    <form action="header.php" method="POST"> 
                        
                        <div class="card" id="item1">
                          
                            <img src="apple.jpg" height="200" width="175">knlv
                            <div class="card-footer ">TOMOTO<b>(1kg)</b><br><b>₹ 40 <button class="rounded-pill"name="Add_To_Cart" style="background-color: yellow; margin-left: 50px;">CART</button></b></div>
                            <input type="hidden" name="item_name" value="TOMOTO">
                            <input type="hidden" name="price" value="40">

                        </div> </form>
                    </div>
                </div>
                <div class="col-md-2">
                    <form action="header.php" method="POST"> 
                        
                        <div class="card" id="item1">
                         
                            
                            <img src="potato.jpg" height="200" width="175">
                            <div class="card-footer ">POTOTO<b>(1kg)</b><br><b>₹ 50<button class="rounded-pill"name="Add_To_Cart" style="background-color: yellow; margin-left: 50px;">CART</button></b></div>
                            <input type="hidden" name="item_name" value="POTOTO">
                            <input type="hidden" name="price" value="50">   </div> </form>
                    </div>
                </div>
                <div class="col-md-2">
                    <form action="header.php" method="POST"> 
                        
                        <div class="card" id="item1">
                          
                            <img src="onions.jpg" height="200" width="175">
                            <div class="card-footer ">ONIONS<b>(1kg)</b><br><b>₹ 60<button class="rounded-pill"name="Add_To_Cart" style="background-color: yellow; margin-left: 50px;">CART</button></b></div>
                            <input type="hidden" name="item_name" value="ONIONS">
                            <input type="hidden" name="price" value="60"> </div> </form>
                    </div>
                </div>
                <div class="col-md-2">
                    <form action="header.php" method="POST"> 
                
                        <div class="card" id="item1">
                            
                            <img src="garlic.jpg" height="200" width="175">
                            <div class="card-footer ">GARLIC<b>(1kg)</b><br><b>₹ 30<button class="rounded-pill"name="Add_To_Cart" style="background-color: yellow; margin-left: 50px;">CART</button></b></div>
                            <input type="hidden" name="item_name" value="GARLIC">
                            <input type="hidden" name="price" value="30"> </div> </form>
                    </div>
                </div>
                <div class="col-md-2">
                  
                    </div>
                </div>
               
                <br><br>
        <!--

            courasle start
      <br><br>
        <div class="container" align="center"><br><br>
            <div class="carousel slide" id="slider" data-bs-ride="carousel">
            
            <ol class="carousel-indicators">
            <li data-bs-target="#slider" data-bs-slide-to="0" class="active"></li>
            <li data-bs-target="#slider" data-bs-slide-to="1"></li>
            </ol>
            
            <div class="carousel-inner">
            <div class="carousel-item active" data-bs-interval="6000">
            <img src="veg.jpg"  height="350 " width="800">
            <div class="carousel-caption">
           
            </div>
            </div>
            <div class="carousel-item">
            <img src="veg2.jpg"  height="350" width="800">
            </div>
            </div>
            
            <a href="#slider" class="carousel-control-prev" data-bs-slide="prev">
            <span class="carousel-control-prev-icon"></span>
            </a>
            <a href="#slider" class="carousel-control-next" data-bs-slide="next">
            <span class="carousel-control-next-icon"></span>
            </a>
            
            </div>
            </div>

            <!--
                end carusel
            
                <div class="conatainer"><br><br>
                    <div  class="row" >
                        <div class="col-md-2">
                         
                                
                            </div>
                        </div>
                        
                        <div class="col-md-2">
                            <form action="head.php" method="POST"> 
                         
                                <div class="card" id="item1">
                                    
                                    <img src="red cabbage.jpg" height="200" width="175">
                                    <div class="card-footer ">RED CABBAGE<b>(1kg)</b><br><b>₹ 60<button class="rounded-pill"name="Add_To_Cart" style="background-color: yellow; margin-left: 50px;">CART</button></b></div>
                                    <input type="hidden" name="item_name" value="RED CABBAGE">
                                    <input type="hidden" name="price" value="60"> </div> </form>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <form action="head.php" method="POST"> 
                              
                                <div class="card" id="item1">
                                    
                                    <img src="green cabbage.jpg" height="200" width="175">
                                    <div class="card-footer ">GREEN CABBAGE<b>(1kg)</b><br><b>₹ 60<button class="rounded-pill"name="Add_To_Cart" style="background-color: yellow; margin-left: 50px;">CART</button></b></div>
                                    <input type="hidden" name="item_name" value="GREEN CABBAGE">
                                    <input type="hidden" name="price" value="60">
                                </div> </form>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <form action="head.php" method="POST"> 
                          
                                <div class="card" id="item1">
                                    
                                    <img src="cauliflower.jpg" height="200" width="175">
                                    <div class="card-footer ">CAULIFLOWER<b>(1kg)</b><br><b>₹ 50<button class="rounded-pill"name="Add_To_Cart" style="background-color: yellow; margin-left: 50px;">CART</button></b></div>
                                    <input type="hidden" name="item_name" value="CAULIFLOWER">
                                    <input type="hidden" name="price" value="50"> </div>
                            </div> </form>
                        </div>
                        <div class="col-md-2">
                            <form action="head.php" method="POST"> 
                               
                                <div class="card" id="item1">
                                    
                                    <img src="radish.jpg" height="200" width="175">
                                    <div class="card-footer ">RADDISH<b>(1kg)</b><br><b>₹ 40<button class="rounded-pill"name="Add_To_Cart" style="background-color: yellow; margin-left: 50px;">CART</button></b></div>
                                    <input type="hidden" name="item_name" value="RADDISH">
                                    <input type="hidden" name="price" value="40"> </div> </form>
                            </div>
                        </div>
                        <div class="col-md-2">
                           
                            </div>
                        </div>

                        <div class="conatainer"><br><br>
                            <div  class="row" >
                                <div class="col-md-2">
                                    <form action="head.php" method="POST"> 
                                    </form>
                                    </div>
                                </div>
                                
                                <div class="col-md-2">
                                    <form action="head.php" method="POST"> 
                                       
                                        <div class="card" id="item1">
                                            
                                            <img src="bittergurd.jpg" height="200" width="175">
                                            <div class="card-footer ">BITTERGURD<b>(1kg)</b><br><b>₹ 35<button class="rounded-pill"name="Add_To_Cart" style="background-color: yellow; margin-left: 50px;">CART</button></b></div>
                                            <input type="hidden" name="item_name" value="BITTERGURD">
                                            <input type="hidden" name="price" value="35">  </div> </form>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <form action="head.php" method="POST"> 
                                      
                                        <div class="card" id="item1">
                                            
                                            <img src="beans.jpg" height="200" width="175">
                                            <div class="card-footer ">BEANS<b>(1kg)</b><br><b>₹ 25<button class="rounded-pill"name="Add_To_Cart" style="background-color: yellow; margin-left: 50px;">CART</button></b></div>
                                            <input type="hidden" name="item_name" value="BEANS">
                                            <input type="hidden" name="price" value="25"> </div> </form>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <form action="head.php" method="POST"> 
                                   
                                        <div class="card" id="item1">
                                            
                                            <img src="bottklegaurs.jpg" height="200" width="175">
                                            <div class="card-footer ">CALABASH <b>(1kg)</b><br><b>₹ 35<button class="rounded-pill"name="Add_To_Cart" style="background-color: yellow; margin-left: 50px;">CART</button></b></div>
                                            <input type="hidden" name="item_name" value="CALABASH">
                                            <input type="hidden" name="price" value="35"> </div> </form>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <form action="head.php" method="POST"> 
                                  
                                        <div class="card" id="item1">
                                            
                                            <img src="drumstick.jpeg" height="200" width="175">
                                            <div class="card-footer ">DRUMSTICK<b>(1kg)</b><br><b>₹ 40<button class="rounded-pill"name="Add_To_Cart" style="background-color: yellow; margin-left: 50px;">CART</button></b></div>
                                            <input type="hidden" name="item_name" value="DRUMSTICK">
                                            <input type="hidden" name="price" value="40"> </div> </form>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                  
                                    </div>
                                </div>


                               
                                <div class="conatainer"><br><br>
                                    <div  class="row" >
                                        <div class="col-md-2">
                                           
                                                
                                            </div> 
                                        </div>
                                        
                                        <div class="col-md-2">
                                            <form action="head.php" method="POST"> 
                                                
                                                <div class="card" id="item1">
                                                    
                                                    <img src="chilli.jpg" height="200" width="175">
                                                    <div class="card-footer ">CHILLI<b>(1kg)</b><br><b>₹ 70<button class="rounded-pill"name="Add_To_Cart" style="background-color: yellow; margin-left: 50px;">CART</button></b></div>
                                                    <input type="hidden" name="item_name" value="CHILLI">
                                                    <input type="hidden" name="price" value="70"> </div> </form>
                                            </div>
                                        </div>
                                        <div class="col-md-2">
                                            <form action="head.php" method="POST"> 
                                                
                                                <div class="card" id="item1">
                                                    
                                                    <img src="corn.jpg" height="200" width="175">
                                                    <div class="card-footer ">CORN(3pices)<br><b>₹ 30<button class="rounded-pill"name="Add_To_Cart" style="background-color: yellow; margin-left: 50px;">CART</button></b></div>
                                                    <input type="hidden" name="item_name" value="CORN">
                                                    <input type="hidden" name="price" value="30">  </div> </form>
                                            </div>
                                        </div>
                                        <div class="col-md-2">
                                            <form action="head.php" method="POST"> 
                                                
                                                <div class="card" id="item1">
                                                    
                                                    <img src="eggplant.jpg" height="200" width="175">
                                                    <div class="card-footer ">EGG PLANT<b>(1kg)</b><br><b>₹ 20<button class="rounded-pill"name="Add_To_Cart" style="background-color: yellow; margin-left: 50px;">CART</button></b></div>
                                                    <input type="hidden" name="item_name" value="EGG PLANT">
                                                    <input type="hidden" name="price" value="20"> </div> </form>
                                            </div>
                                        </div>
                                        <div class="col-md-2">
                                            <form action="head.php" method="POST"> 
                                                
                                                <div class="card" id="item1">
                                                    
                                                    <img src="ginger.jpg" height="200" width="175">
                                                    <div class="card-footer ">GINGER<b>(1kg)</b><br><b>₹ 20<button class="rounded-pill"name="Add_To_Cart" style="background-color: yellow; margin-left: 50px;">CART</button></b></div>
                                                    <input type="hidden" name="item_name" value="GINGER">
                                                    <input type="hidden" name="price" value="20"></div> </form>
                                            </div>
                                        </div>
                                        <div class="col-md-2">
                                        
                                                
                                            </div>
                                        </div>
                                        <div class="col-md-2">
                                           
                                                
                                            </div>
                                        </div>
                
                                        <div class="conatainer"><br><br>
                                            <div  class="row" >
                                                <div class="col-md-2">
                                                  
                                                        
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-2">
                                                    <form action="head.php" method="POST"> 
                                                       
                                                        <div class="card" id="item1">
                                                            
                                                            <img src="corinder.jpg" height="200" width="175">
                                                            <div class="card-footer ">CORINDER<b>(1kg)</b><br><b>₹ 20<button class="rounded-pill"name="Add_To_Cart" style="background-color: yellow; margin-left: 50px;">CART</button></b></div>
                                                            <input type="hidden" name="item_name" value="CORINDER">
                                                            <input type="hidden" name="price" value="20">    </div> </form>
                                                    </div>
                                                </div>
                                                <div class="col-md-2">
                                                    <form action="head.php" method="POST"> 
                                                      
                                                        <div class="card" id="item1">
                                                            
                                                            <img src="gongora.jpg" height="200" width="175">
                                                            <div class="card-footer ">GONGORU<b>(1kg)</b><br><b>₹ 20<button class="rounded-pill"name="Add_To_Cart" style="background-color: yellow; margin-left: 50px;">CART</button></b></div>
                                                            <input type="hidden" name="item_name" value="GONGORU">
                                                            <input type="hidden" name="price" value="20"></div> </form>
                                                    </div>
                                                </div>
                                                <div class="col-md-2">
                                                    <form action="head.php" method="POST"> 
                                                   
                                                        <div class="card" id="item1">
                                                            
                                                            <img src="mushroom.jpg" height="200" width="175">
                                                            <div class="card-footer ">MUSHROOM<b>(1kg)</b><br><b>₹ 80<button class="rounded-pill"name="Add_To_Cart" style="background-color: yellow; margin-left: 50px;">CART</button></b></div>
                                                            <input type="hidden" name="item_name" value="">
                                                            <input type="hidden" name="price" value="200">   </div> </form>
                                                    </div>
                                                </div>
                                                <div class="col-md-2">
                                                    <form action="head.php" method="POST"> 
                                                  
                                                        <div class="card" id="item1">
                                                            
                                                            <img src="lomons.jpg" height="200" width="175">
                                                            <div class="card-footer ">LEMONS(4 pices)<br><b>₹ 20<button class="rounded-pill"name="Add_To_Cart" style="background-color: yellow; margin-left: 50px;">CART</button></b></div>
                                                            <input type="hidden" name="item_name" value="LEMONS">
                                                            <input type="hidden" name="price" value="20"> </div> </form>
                                                    </div>
                                                </div>
                                                <div class="col-md-2">
                                                   
                                                    </div>
                                                </div>
                                                <div class="col-md-2">
                                                   
                                                    </div>
                                                </div>
                        
                                                <div class="conatainer"><br><br>
                                                    <div  class="row" >
                                                        <div class="col-md-2">
                                                            
                                                            </div>
                                                        </div>
                                                        
                                                        <div class="col-md-2">
                                                            <form action="head.php" method="POST"> 
                                                               
                                                                <div class="card" id="item1">
                                                                    
                                                                    <img src="carrot.jpg" height="200" width="175">
                                                                    <div class="card-footer ">CARROT<b>(1kg)</b><br><b>₹ 30<button class="rounded-pill"name="Add_To_Cart" style="background-color: yellow; margin-left: 50px;">CART</button></b></div>
                                                                    <input type="hidden" name="item_name" value="CARROT">
                                                                    <input type="hidden" name="price" value="30"> </div> </form>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-2">
                                                            <form action="head.php" method="POST"> 
                                                              
                                                                <div class="card" id="item1">
                                                                    
                                                                    <img src="gongora.jpg" height="200" width="175">
                                                                    <div class="card-footer ">GONGORU<b>(1kg)</b><br><b>₹ 30<button class="rounded-pill"name="Add_To_Cart" style="background-color: yellow; margin-left: 50px;">CART</button></b></div>
                                                                    <input type="hidden" name="item_name" value="GONGORU">
                                                                    <input type="hidden" name="price" value="30">
                                                                </div> </form>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-2">
                                                            <form action="head.php" method="POST"> 
                                                           
                                                                <div class="card" id="item1">
                                                                    
                                                                    <img src="mushroom.jpg" height="200" width="175">
                                                                    <div class="card-footer ">MUSHROOM<b>(1kg)</b><br><b>₹ 30<button class="rounded-pill"name="Add_To_Cart" style="background-color: yellow; margin-left: 50px;">CART</button></b></div>
                                                                    <input type="hidden" name="item_name" value="MUSHROOM">
                                                                    <input type="hidden" name="price" value="30"> </div> </form>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-2">
                                                            <form action="head.php" method="POST"> 
                                                          
                                                                <div class= "card"id="item1">
                                                                    
                                                                    <img src="lomons.jpg" height="200" width="175">
                                                                    <input type="hidden" name="item_name" value="LEMONS">
                                                                    <input type="hidden" name="price" value="20">   <div class="card-footer ">LEMONS<b>(1kg)</b><br><b>₹ 30<button class="rounded-pill"name="Add_To_Cart" style="background-color: yellow; margin-left: 50px;">CART</button></b></div> </form>
                                                                </div>
                                                            </div>
                                                        </div>

          -->
       
    </body>
</html>