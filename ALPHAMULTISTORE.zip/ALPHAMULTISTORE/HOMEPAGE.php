<?php
session_start();


?>


<html>
    <head>
        <title>



        </title>
        <link rel="stylesheet" href="style1.css">
        <style>
           body{
    height: 100%;
    width: 100%;
    background-image: linear-gradient(rgba(0,0,0,0.4),rgba(0,0,0,0.4)),url(12.jpeg);
    background-position: center;
    background-size: 100% 100%;
    background-repeat: no-repeat;
    position: relative;
    
   
    
}
           
        </style>
    </head>
    <body>
        <div class="full-page">
            <div class="navbar">
                <div ><a href="">SAI</a></div>
                <nav>
                    <ul id="menuitem">
                        
                        <li><a href="ABOUT12.html">ABOUT</a></li>
                       
                        <li><a href="contcat.html">CONTACT</a></li>
                        <li>
                            <button class="login-btn" onclick="document.getElementById('login-form').style.display='block'"style="width:auto;">LOGIN</button>
                           
                        </li> 
                        <li><a href="REGISTER.php">REGISTER</a></li>
                       
                    </ul>
                </nav>
            </div>
            <div id="login-form" class="login-page">
                <div class="form-box">
                    <div class="button-box">
                        <div id="btn">  <h2 style="color:white; margin-left:70px;">LOGIN </h2></div>
                        
                       
                        
                        </div>
                       
                        <form id="login" action="login.php"  method="POST" class="input-group-login">
                        
                        <input type="text" class="input-field"  name="email" placeholder="email" required><br><br>
                        <input type="password" class="input-field" name="password" placeholder="enterpassword"><br><br><br><br>
                        
                      
                       
                    
                        <button type="submit" class="submit-btn"  >LOG IN</button>
                       
                        </form>   
                        
                </div>
            </div>
        </div>
    </body>
    <script>
        

</script>

    
   
       
</html>
