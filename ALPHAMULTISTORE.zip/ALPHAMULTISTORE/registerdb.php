<?php
    $connect=mysqli_connect("localhost","root","","AMSPRO");
?>