<html>
    <head>
        <title>

        </title>
        <link rel="stylesheet" href="register.css">
        <style>
            body{
                background-image: url("home.jpg");
                height: 100%; 
                background-position: center;
                background-repeat: no-repeat;
                
                background-size: 100% 300vh;
                
             }
             ::placeholder{
                color:white
             }
           
        </style>
    </head>
    <body>
        <div class="full-page">
            <div class="navbar">
                <div ><a href="">SAI</a></div>
                <nav>
                    <ul id="menuitem">
                        
                        
                        <li>
                            <button class="login-btn" onclick="document.getElementById('login-form').style.display='block'"style="width:auto;">
                            <img src="registerphp.gif" height="80" width="120"></button>
                           
                        </li> 
                       
                    </ul>
                </nav>
            </div>



            <div id="login-form" class="login-page">
                <div class="form-box">
                    <div class="button-box">
                        <div id="btn"></div>
                 
                        
                        
                        
                        </div>
                        <!--<form id="login" action="py.php" class="input-group-login">
                        <input type="text" class="input-field" placeholder="NAME" required>
                        <input type="text" class="input-field" placeholder="MOBILE NO" required>
                        <input type="email" class="input-field" placeholder="email" required>
                        <input type="password" class="input-field" placeholder="enterpassword">
                        <input type="checkbox" class="check-box"><span>rember your password</span>
                        <button type="submit" class="submit-btn">LOG IN</button>
                        </form>   --><br><br><br><br><br>
                        <form id="form" style="color:orange" id="register" class="input-group-register"  action="rsbd.php" method="POST">
         
         <input type="text" name="uname" id="uname"  class="input-feild" placeholder="username"><br>
      
         
         <input type ="password" id="pwd" name="password" class="input-feild" placeholder="Password"><br>
         <br>
         
 
         <input type="password" id="cpwd"  name="psd"class="input-feild" placeholder="Confirm Password ">
         <br><br>
         
       
         <input type="text" id="num" name="ps" class="input-feild" placeholder="Mobile Number">
         <br><br>
         
         
         <input type="text" id="mail" class="input-feild" name="email" placeholder="Email Id">

        
         <br><br><br><br>
         <i><mark><span id="perror"></span></mark></i>
         
        
         <br>
         &nbsp;
         <button type="submit"   class="submit-btn"  style="margin-left:50px;">REGISTER</button>
         </form>
         </th></table>
     <script>
             let form=document.getElementById('form');
             form.addEventListener("submit",event=>{event.preventDefault();validate();});

         function validate()
         {
             let  uname=document.getElementById('uname');
             let password=document.getElementById('pwd');
             let cpassword=document.getElementById('cpwd');
             let number=document.getElementById('num');
             let mail=document.getElementById("mail").value;
             let perror=document.getElementById('perror');
             let name=uname.value.trim();
             let pwd=password.value.trim();
             let cpwd=cpassword.value.trim();
             let n=number.value.trim();
             
             if(name=="" || name==null)
             {
                 perror.innerText="username cannot be empty";
                 return false;
             }
             if(name.length<3)
             {
                 perror.innerText='Username should be atleast 3 characters';
                 return false;
             }
             if((/[0-9!@#$%^&]/).test(name))
             {
                 perror.innerText='Only alphabet allowed in username';
                 return false;
             }
             if(!(/[A-Z]{1}/).test(name))
             {
                 perror.innerText="First letter must be capital in username";
                 return false;
             }
             if(pwd.length<8)
             {
                 perror.innerText="Password must contain 8 characters";
                 return false;
             }
             if(!(/[A-Z]{1}[a-zA-Z0-9@#$%&]+/).test(pwd))
             {
                 perror.innerText="Password must start with capital letters and should contain numbers or symbols ";
                 return false;
             }
             if(pwd != cpwd)
             {
                 perror.innerText="Confirm Password not Matched";
                 return false;
             }
             if(n=="")
             {
                 perror.innerText="Mobile number can't be empty";
                 return false;
             }
             if(!(/[0-9]/).test(n))
             { 
                 perror.innerText='Mobile number should contain numbers only';
                 return false;
             }
             if(n.length!=10)
             {
                 perror.innerText='Mobile number should contain 10 digits';
                 return false;
             }
             
             if(!(/[6-9]{1}[0-9]{9}/).test(n))
             {
                 perror.innerText="Mobile number should start with number between 6 to 9 only";
                 return false;
             }

             if(mail=='')
             {
                 perror.innerText="email can't be empty";
                 return false;
             }
             if(!(/[a-zA-Z0-9_\-\.]+[@][a-zA-Z0-9]+[\.]([a-z]{2,6})$/).test(mail))
             {
                 perror.innerText="Give valid Email";
                 return false;
             }

             form.submit();

         }

     function register(){
            var con=confirm("do you want to login the web page");
            if(con)
            {
                window.location.href="REGISTER.php";

            }
            else
            {
                window.location.href="REGISTER.php";
            }
        
     }
             </script>
                        
                </div>
            </div>
        </div>
    </body>
</html>