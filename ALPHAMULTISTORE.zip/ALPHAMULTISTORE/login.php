<?php
session_start();


?>

<?php
$_SESSION['email']=$_POST['email'];
$_SESSION['pass']=$_POST['password'];


include "registerdb.php";
if($connect)
{
    echo "yes";
}
 
$email=$_POST['email'];
 $pass=$_POST['password'];


 $query="select *from AMSLOG;";
 $que=mysqli_query($connect,$query);
if(mysqli_num_rows($que)){


while($row=mysqli_fetch_assoc($que))

    {
        if($row['GMAILID_ID']==$email)
        {
            if($row['PASSWORD']==$pass)
            {
                header("Location:veg123.php");
                exit();
                return false;
            }
            else{
               echo "<script>
               alert('REGISTER FIRST');
               window.location.href='REGISTER.php';
               </script>";
            }
            
        }

        else{
            echo "<script>
               alert('REGISTER FIRST');
               window.location.href='REGISTER.php';
               </script>";
        }
        
    }

}

?>

