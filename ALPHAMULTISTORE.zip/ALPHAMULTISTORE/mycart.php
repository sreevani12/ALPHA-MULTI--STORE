<?php
include('header.php');
session_start();
?>
<!DOCTYPE html>
<html>
    <head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
        <style>
        h2{
            
            font-family: bolder;
            font-style: bold;
        }
        h1{
            
            font-family: bolder;
            font-style: bold;
        }
        td{
            font-size: 0.5cm;
            font-family: bolder;
            font-style: bold;
        }
        a{
            text-decoration:none;
            color:black;
        }
        </style>
    </head>
    <body>
        <div class="container">
        <div class="row">
            <div class="col-md-12 mt-5">
            <h1> MY CART</h1>
            </div>
            <div class="col-8 border bg-light p-5">
                <table class="table">
                    <tbody class="text-center">
                        <tr>
                            <td>serial no</td>
                            <td>Item name</td>
                            <td>item price</td>
                            <td>quantity</td>
                            
                        </td>
                        <?php
                        $total=0;
                        $s=0;
                        if(isset($_SESSION['cart'])){
                            foreach($_SESSION['cart'] as $kay => $value){
                                $total=$total+$value['price'];
                                $s=$s+1;
                                echo"<tr>
                                <th>$s</th>
                                <th>$value[Item_Name]</th>
                                <th>$value[price]</th>
                                <th><input type='number' class='text-center' value='$value[quantity]' size=2 min='1' max='10'></th>
                                <th>
                                <form action='header.php' method='post'>
                                <button  name='remove' class='btn-sm btn-outline-danger'> remove</btn></th>
                                <input type='hidden' name='Item_Name' value='$value[Item_Name]'>
                                </form>
                                </tr>"; 
                            }
                        }
                        
                        ?>
                    </tbody>
                </table>
                    </div>
            <div class="col-md-3 p-5 rounded border bg-light">
                        <h2>TOTAL:<?php echo"$total"?></h2><br>
                        <a href="paym.html"><h2 class="btn btn-success">Proceed to PAY</h2></a>
                        <h1>(OR)</h1>
                        <h2 class="btn btn-info" ><a href="home.php">Back to home</a></h2>

                       
            </div>
        </div>

        </div>
    </body>
</html>