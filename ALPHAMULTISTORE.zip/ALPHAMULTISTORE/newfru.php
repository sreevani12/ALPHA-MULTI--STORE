<?php 
    include("header.php");
    session_start();
    
?>

<!DOCTYPE html>
<html>
    <head>
        <title>
                NAVIGATION
        </title>

        <style>
            .card-body.img:hover{
                transform: scale(1.25,1.25);
            }
          .h1{
            font: bold;
            
          }
        </style>
        <link rel="stylesheet" href="bootstrap.css">
        <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>



    </head>
    <body>
      
        <div class="container"  style="color:aqua;">
            <nav class="navbar navbar-expand-lg bg-secondary fixed-top"  style="color:aqua;">
            <b style="padding-left: 550px;"><h1>FRUITS</h1></b>
            <ul class="navbar-nav">
                <li class="nav-item" class="cart" id="cart">
                    <?php 
                    $count=0;
                    if(isset($_SESSION['cart'])){
                        $count=count($_SESSION['cart']);
                    }
                    ?>
                    <b class="btn btn-outline-success"><i class="fa fa-shopping-cart" style="font-size:20px;color:rgb(15, 10, 10)"><a href="mycart.php">MY CART(<b style="color:red"><?php echo $count;?></b>)</a> </i></b>
                    <div id="title"></div>
                </li>
                </ul>

               
            </nav>
           
        </div>

        <!--cards-->
         <div class="conatainer" ><br><br><br><br>




            <!--
                courasal 
            -->
            <div class="container" align="center">
                <div class="carousel slide" id="slider" data-bs-ride="carousel">
                
                <ol class="carousel-indicators">
                <li data-bs-target="#slider" data-bs-slide-to="0" class="active"></li>
                <li data-bs-target="#slider" data-bs-slide-to="1"></li>
                </ol>
                
                <div class="carousel-inner">
                <div class="carousel-item active" data-bs-interval="6000">
                <img src="fru.jpg" width="900" height="350">
                <div class="carousel-caption">
               
                </div>
                </div>
                <div class="carousel-item">
                <img src="fru2.jpg"  width="900" height="350">
                </div>
                </div>
                
                <a href="#slider" class="carousel-control-prev" data-bs-slide="prev">
                <span class="carousel-control-prev-icon"></span>
                </a>
                <a href="#slider" class="carousel-control-next" data-bs-slide="next">
                <span class="carousel-control-next-icon"></span>
                </a>
                
                </div>
                </div><br><br>



                <!--end of carulse-->
            <div  class="row" >
                <div class="col-md-2">
                    <div class="bg-light">
                        
                    </div>
                </div>
                
                <div class="col-md-2">
                    <div class="bg-light">
                        <form action="header.php" method="POST">  
                        <div class= "card"id="item1" >
                          
                            <img src="apple.jpg" height="200" width="175">
                            <div class="card-footer ">APPLE<b>(1kg)</b><br><b>₹ 200 <button class="rounded-pill" style="background-color: yellow; margin-left: 40px;"name="Add_To_Cart">CART</button></b></div>
                            <input type="hidden" name="item_name" value="APPLE">
                              <input type="hidden" name="price" value="200">
                           

                        </div>
                    </form>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="bg-light">
                        <form action="header.php" method="POST">  
                        <div class= "card"id="item1">
                         
                            
                            <img src="banana.jpeg" height="200" width="175">
                            <div class="card-footer ">BANANA<b>(12 pices)</b><br><b>₹ 50<button class="rounded-pill" style="background-color: yellow; margin-left: 50px;"name="Add_To_Cart">CART</button></b></div>
                            <input type="hidden" name="item_name" value="BANANA">
                            <input type="hidden" name="price" value="50">
                        </div> </form>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="bg-light">
                        <form action="header.php" method="POST">  
                        <div class= "card"id="item1">
                          
                            <img src="blackcurrant.jpg" height="200" width="175">
                            <div class="card-footer ">BLACKCURRANT<b>(1kg)</b><br><b>₹ 60<button class="rounded-pill" style="background-color: yellow; margin-left: 50px;"name="Add_To_Cart">CART</button></b></div>
                            <input type="hidden" name="item_name" value="BLACKCURRANT">
                            <input type="hidden" name="price" value="60">
                        </div> </form>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="bg-light">
                        <form action="header.php" method="POST">  
                        <div class= "card"id="item1">
                            
                            <img src="green cocount.jpg" height="200" width="175">
                            <div class="card-footer ">COCONUT<b>(1 pices)</b><br><b>₹ 50<button class="rounded-pill" style="background-color: yellow; margin-left: 50px;"name="Add_To_Cart">CART</button></b></div>
                            <input type="hidden" name="item_name" value="COCONUT">
                            <input type="hidden" name="price" value="50">
                        </div> </form>
                    </div>
                </div>
                
                <div class="col-md-2">
                    <div class="bg-light">
                        
                    </div>
                </div>
        
                <div class="conatainer"><br><br>
                    <div  class="row" >
                        <div class="col-md-2">
                            <div class="bg-light">
                                
                            </div>
                        </div>
                        
                        <div class="col-md-2">
                            <div class="bg-light">
                                <form action="header.php" method="POST">  
                                <div class= "card"id="item1">
                                    
                                    <img src="dragon.jpg" height="200" width="175">
                                    <div class="card-footer ">DRAGON<b>(1 pices)</b><br><b>₹ 160<button class="rounded-pill" style="background-color: yellow; margin-left: 40px;"name="Add_To_Cart">CART</button></b></div>
                               
                                    <input type="hidden" name="item_name" value="DRAGON">
                                    <input type="hidden" name="price" value="160"> </div> </form>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="bg-light">
                                <form action="header.php" method="POST">  
                                <div class= "card"id="item1">
                                    
                                    <img src="grapes.jpeg" height="200" width="175">
                                    <div class="card-footer ">GRAPES<b>(1kg)</b><br><b>₹ 60<button class="rounded-pill" style="background-color: yellow; margin-left: 50px;"name="Add_To_Cart">CART</button></b></div>
                                    <input type="hidden" name="item_name" value="GRAPES">
                                    <input type="hidden" name="price" value="60"> </div> </form>
                            </div>
                        </div>
                       
                        <div class="col-md-2">
                            <div class="bg-light">
                                <form action="header.php" method="POST">  
                                <div class= "card"id="item1">
                                    
                                    <img src="custard apple.jpg" height="200" width="175">
                                    <div class="card-footer ">CUSTARD APPLE<b>(1kg)</b><br><b>₹ 50<button class="rounded-pill" style="background-color: yellow; margin-left: 50px;"name="Add_To_Cart">CART</button></b></div>
                                    <input type="hidden" name="item_name" value="CUSTARD APPLE">
                                    <input type="hidden" name="price" value="50"></div> </form>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="bg-light">
                                <form action="header.php" method="POST">  
                                <div class= "card"id="item1">
                                    
                                    <img src="guvava.jpeg" height="200" width="175">
                                    <div class="card-footer ">GUVAVA<b>(1kg)</b><br><b>₹ 40<button class="rounded-pill" style="background-color: yellow; margin-left: 50px;"name="Add_To_Cart">CART</button></b></div>
                                    <input type="hidden" name="item_name" value="GUVAVA">
                                    <input type="hidden" name="price" value="40"> </div> </form>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="bg-light">
                                
                            </div>
                        </div>

                        <div class="conatainer"><br><br>
                            <div  class="row" >
                                <div class="col-md-2">
                                    <div class="bg-light">
                                        
                                    </div>
                                </div>
                                
                                <div class="col-md-2">
                                    <div class="bg-light">
                                        <form action="header.php" method="POST">  
                                        <div class= "card"id="item1">
                                            
                                            <img src="jujube.jpg" height="200" width="175">
                                            <div class="card-footer ">JUJUBE<b>(1kg)</b><br><b>₹ 35<button class="rounded-pill" style="background-color: yellow; margin-left: 50px;"name="Add_To_Cart">CART</button></b></div>
                                            <input type="hidden" name="item_name" value="JUJUBE">
                                            <input type="hidden" name="price" value="35"> </div> </form>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="bg-light">
                                        <form action="header.php" method="POST">  
                                        <div class= "card"id="item1">
                                            
                                            <img src="kiwi.jpeg" height="200" width="175">
                                            <div class="card-footer ">KIWI<b>(1kg)</b><br><b>₹ 50<button class="rounded-pill" style="background-color: yellow; margin-left: 50px;"name="Add_To_Cart">CART</button></b></div>
                                            <input type="hidden" name="item_name" value="KIWI">
                                            <input type="hidden" name="price" value="50">  </div> </form>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="bg-light">
                                        <form action="header.php" method="POST">  
                                        <div class= "card"id="item1">
                                            
                                            <img src="lychees.jpeg" height="200" width="175">
                                            <input type="hidden" name="item_name" value="LYCHEES">
                                            <input type="hidden" name="price" value="200"> <div class="card-footer ">LYCHEES<b>(1kg)</b><br><b>₹ 200<button class="rounded-pill" style="background-color: yellow; margin-left: 40px;"name="Add_To_Cart">CART</button></b></div>
                                        </div> </form>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="bg-light">
                                        <form action="header.php" method="POST">  
                                        <div class= "card"id="item1">
                                            
                                            <img src="mango.jpg" height="200" width="175">
                                            <input type="hidden" name="item_name" value="MANGO">
                                            <input type="hidden" name="price" value="40">   <div class="card-footer ">MANGO<b>(1kg)</b><br><b>₹ 40<button class="rounded-pill" style="background-color: yellow; margin-left: 50px;"name="Add_To_Cart">CART</button></b></div>
                                        </div> </form>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="bg-light">
                                        
                                    </div>
                                </div>


                               
                                <div class="conatainer"><br><br>
                                    <div  class="row" >
                                        <div class="col-md-2">
                                            <div class="bg-light">
                                                
                                            </div>
                                        </div>
                                        
                                        <div class="col-md-2">
                                            <div class="bg-light">
                                                <form action="header.php" method="POST">  
                                                <div class= "card"id="item1">
                                                    
                                                    <img src="orange.jpeg" height="200" width="175">
                                                    <div class="card-footer ">ORANGE<b>(1kg)</b><br><b>₹ 70<button class="rounded-pill" style="background-color: yellow; margin-left: 50px;"name="Add_To_Cart">CART</button></b></div>
                                                    <input type="hidden" name="item_name" value="ORANGE">
                                                    <input type="hidden" name="price" value="70">  </div> </form>
                                            </div>
                                        </div>
                                        <div class="col-md-2">
                                            <div class="bg-light">
                                                <form action="header.php" method="POST">  
                                                <div class= "card"id="item1">
                                                    
                                                    <img src="papaya.jpeg" height="200" width="175">
                                                    <div class="card-footer ">PAPAYA(1 kg)<br><b>₹ 30<button class="rounded-pill" style="background-color: yellow; margin-left: 50px;"name="Add_To_Cart">CART</button></b></div>
                                                    <input type="hidden" name="item_name" value="PAPAYA">
                                                    <input type="hidden" name="price" value="30"> </div> </form>
                                            </div>
                                        </div>
                                        <div class="col-md-2">
                                            <div class="bg-light">
                                                <form action="header.php" method="POST">  
                                                <div class= "card"id="item1">
                                                    
                                                    <img src="passionfruit..jpg" height="200" width="175">
                                                    <div class="card-footer ">PASSION<b>(1kg)</b><br><b>₹ 200<button class="rounded-pill" style="background-color: yellow; margin-left: 40px;"name="Add_To_Cart">CART</button></b></div>
                                                    <input type="hidden" name="item_name" value="PASSION">
                                                    <input type="hidden" name="price" value="200"> </div> </form>
                                            </div>
                                        </div>
                                        <div class="col-md-2">
                                            <div class="bg-light">
                                                <form action="header.php" method="POST">  
                                                <div class= "card"id="item1">
                                                    
                                                    <img src="pineapple.jpeg" height="200" width="175">
                                                    <div class="card-footer ">PINEAPPLE<b>(1 pices)</b><br><b>₹ 60<button class="rounded-pill" style="background-color: yellow; margin-left: 50px;"name="Add_To_Cart">CART</button></b></div>
                                                    <input type="hidden" name="item_name" value="PINEAPPLE">
                                                    <input type="hidden" name="price" value="60"></div> </form>
                                            </div>
                                        </div>
                                        <div class="col-md-2">
                                            <div class="bg-light">
                                                
                                            </div>
                                        </div>
                                        <div class="col-md-2">
                                            <div class="bg-light">
                                                
                                            </div>
                                        </div>
                
                                        <div class="conatainer"><br><br>
                                            <div  class="row" >
                                                <div class="col-md-2">
                                                    <div class="bg-light">
                                                        
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-2">
                                                    <div class="bg-light">
                                                        <form action="header.php" method="POST">  
                                                        <div class= "card"id="item1">
                                                            
                                                            <img src="pomegranate.jpg" height="200" width="175">
                                                            <div class="card-footer ">POMEGRANATE<b>(1kg)</b><br><b>₹ 90<button class="rounded-pill" style="background-color: yellow; margin-left: 50px;"name="Add_To_Cart">CART</button></b></div>
                                                            <input type="hidden" name="item_name" value="POMEGRANATE">
                                                            <input type="hidden" name="price" value="90">  </div> </form>
                                                    </div>
                                                </div>
                                                <div class="col-md-2">
                                                    <div class="bg-light">
                                                        <form action="header.php" method="POST">  
                                                        <div class= "card"id="item1">
                                                            
                                                            <img src="sapo.jpeg" height="200" width="175">
                                                            <div class="card-footer ">SAPOTA<b>(1kg)</b><br><b>₹ 50<button class="rounded-pill" style="background-color: yellow; margin-left: 50px;"name="Add_To_Cart">CART</button></b></div>
                                                            <input type="hidden" name="item_name" value="SAPOTA">
                                                            <input type="hidden" name="price" value="50"> </div> </form>
                                                    </div>
                                                </div>
                                                <div class="col-md-2">
                                                    <div class="bg-light">
                                                        <form action="header.php" method="POST">  
                                                        <div class= "card"id="item1">
                                                            
                                                            <img src="staw.jpeg" height="200" width="175">
                                                            <div class="card-footer ">STAWBERRY<b>(1kg)</b><br><b>₹ 120<button class="rounded-pill" style="background-color: yellow; margin-left: 40px;"name="Add_To_Cart">CART</button></b></div>
                                                            <input type="hidden" name="item_name" value="STAWBERRY">
                                                            <input type="hidden" name="price" value="120">  </div> </form>
                                                    </div>
                                                </div>
                                                <div class="col-md-2">
                                                    <div class="bg-light">
                                                        <form action="header.php" method="POST">  
                                                        <div class= "card"id="item1">
                                                            
                                                            <img src="watermelon.jpeg" height="200" width="175">
                                                            <div class="card-footer ">WATER MELON(1 pices)<br><b>₹ 80<button class="rounded-pill" style="background-color: yellow; margin-left: 50px;"name="Add_To_Cart">CART</button></b></div>
                                                            <input type="hidden" name="item_name" value="WATER MELON">
                                                            <input type="hidden" name="price" value="80">  </div> </form>
                                                    </div>
                                                </div>
                                                <div class="col-md-2">
                                                    <div class="bg-light">
                                                        
                                                    </div>
                                                </div>
                                                <div class="col-md-2">
                                                    <div class="bg-light">
                                                        
                                                    </div>
                                                </div>
                        
                                                

        
       
    </body>
</html>