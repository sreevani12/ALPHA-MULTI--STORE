

<?php 
    include("header.php");
    session_start();
    
?>
<!DOCTYPE html>
<html>
    <head>
        <title>food</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
        <style>
        b{
                
            font-family: bolder;
            font-style: bold;
        }
        .card:hover{
            transform:scale(1.07);
        }
        h3{
            
            font-family: bolder;
            font-style: bold;
        }
        h1{
            
            font-family: bolder;
            font-style: bold;
        }
        h5{
            font-size: 0.5cm;
            font-family: bolder;
            font-style: bold;
        }
        img{
            
            border-radius: 30px;
        }
        a{
            text-decoration:none;
            color:black;
        }
    </style>
    </head>
    <body>
        <nav class="navbar navbar-expand-md bg-light justify-content-center navbar-dark navbar-text-md sticky-top">
            <h2 class="navbar-brand mt-1 ms-5"><img src="IMG-20221213-WA0037.jpg" height="80" width="80" class="rounded-pill"></h2>
            <div class="container mt-4">
            <h2><b style="color: rgba(192, 120, 5, 0.9);font-size:1.3cm;" class=" mt-5">ALPHA MULTI STORE</b></h2>
            <ul class="navbar-nav">
                <li class="nav-item" class="cart" id="cart">
                    <?php 
                    $count=0;
                    if(isset($_SESSION['cart'])){
                        $count=count($_SESSION['cart']);
                    }
                    ?>
                    <b class="btn btn-outline-success"><i class="fa fa-shopping-cart" style="font-size:20px;color:rgb(15, 10, 10)"><a href="mycart.php">MY CART(<b style="color:red"><?php echo $count;?></b>)</a> </i></b>
                    <div id="title"></div>
                </li>
                </ul>
        </div>

        </nav>
        <br>
        <?php 
        
        ?>
        <div class="row">
            <div class="col-md-5 mt-5">
                <h1 style="margin-left:100px;" class="mt-5"><img src="pexels-fauxels-3184188.jpg" width="50" height="50" class="rounded-pill">DELICIOUS FOOD ITEMS<img src="pexels-viktoria-alipatova-2668498.jpg" width="50" height="50" class="rounded-pill"></h1>

            </div>
            <div class="col-md-5">
                <h1 style="margin-left:100px;"><img src="assorted-indian-recipes-food-various-spices-rice-wooden-table-92742528.jpg" width="600" height="400" ></h1>

            </div>
        </div>
        <br><br>
        <h3 style="margin-left:150px;">---------------------------------Here Different Categories------------------------------------------</h3>
        <h3 style="margin-left:150px;" class="mt-5">Nonveg-items:</h3>

        <div class="row mt-5" style="margin-left: 170px;">
            <div class="col-2">
            
            <form action="header.php" method="POST">    
            <div class="card" id="item1"> 
                       <h5 style="margin-left:15px;" class="title"><img src="pexels-rajesh-tp-1624487.jpg" width="140" height="160"><br>&nbsp;Chicken Dum &nbsp;&nbsp;Biryani</h5>
                        <b style="margin-left:30px;color: rgb(246, 8, 8);">Cost: ₹200</b>
                    <br><br><button type="submit" class="rounded-pill" style="background-color: yellow;" name="Add_To_Cart">ADD TO CART</button>
                    <input type="hidden" name="item_name" value="Chicken Dum Biryani">
                    <input type="hidden" name="price" value="200">


                    
                </div>

            </form>
            </div>
            <div class="col-2" style="margin-left:0px;">
            
            <form action="header.php" method="POST">    
            <div class="card" id="item1"> 
                       <h5 style="margin-left:15px;" class="title"><img src="noodles.jpg" width="140" height="160"><br>&nbsp;Chicken &nbsp;Noodles</h5><b style="margin-left:30px;color: rgb(246, 8, 8);">Cost: ₹60</b>

                    <br><br><button type="submit" class="rounded-pill" style="background-color: yellow;" name="Add_To_Cart">ADD TO CART</button>
                    <input type="hidden" name="item_name" value="chicken Noodles">
                    <input type="hidden" name="price" value="60">
                    </div>
            </form>
            </div>
            <div class="col-2" style="margin-left:0px;">
            
            <form action="header.php" method="POST">    
            <div class="card" id="item1"> 
                       <h5 style="margin-left:15px;" class="title"><img src="egg noodles.jpg" width="140" height="160px"><br>Egg Noodles</h5><b style="margin-left:30px;color: rgb(246, 8, 8);">Cost: ₹40</b>

                    <br><br><button type="submit" class="rounded-pill" style="background-color: yellow;" name="Add_To_Cart">ADD TO CART</button>
                    <input type="hidden" name="item_name" value="Egg Noodles">
                    <input type="hidden" name="price" value="40">
                    </div>
            </form>
            </div>
            <div class="col-2" style="margin-left:0px;">
            
            <form action="header.php" method="POST">    
            <div class="card" id="item1" style="margin-left:0px;"> 
                       <h5 style="margin-left:15px;" class="title"><img src="egg rice.jpg" width="140" height="160"><br>&nbsp;&nbsp;&nbsp;Egg Rice</h5><b style="margin-left:30px;color: rgb(246, 8, 8);">Cost: ₹80</b>

                    <br><br><button type="submit" class="rounded-pill" style="background-color: yellow;" name="Add_To_Cart">ADD TO CART</button>
                    <input type="hidden" name="item_name" value="Egg Rice">
                    <input type="hidden" name="price" value="80">
                    </div>
            </form>
            </div>
            <div class="col-2" style="margin-left:0px;">
            
            <form action="header.php" method="POST">    
            <div class="card" id="item1" style="margin-left:0px;"> 
                       <h5 style="margin-left:15px;" class="title"><img src="pexels-rajesh-tp-1633525.jpg" width="140" height="160"><br>&nbsp;&nbsp;Chicken &nbsp;&nbsp;Burger</h5><b style="margin-left:30px;color: rgb(246, 8, 8);">Cost: ₹130</b>
                    <br><br><button type="submit" class="rounded-pill" style="background-color: yellow;" name="Add_To_Cart">ADD TO CART</button>
                    <input type="hidden" name="item_name" value="Chicken Burger">
                    <input type="hidden" name="price" value="130">

                </div>
            </form>
            </div>
            <div class="col-2">

            </div>
            
            <div class="col-2 mt-4" style="margin-left:0px;">
            
            <form action="header.php" method="POST">    
            <div class="card" id="item1" style="margin-left:0px;"> 
                       <h5 style="margin-left:15px;" class="title"><img src="kebab.jpg" width="140" height="160"><br>&nbsp;&nbsp;Chicken &nbsp;&nbsp;Kabab</h5><b style="margin-left:30px;color: rgb(246, 8, 8);">Cost: ₹60</b>

                    <br><br><button type="submit" class="rounded-pill" style="background-color: yellow;" name="Add_To_Cart">ADD TO CART</button>
                    <input type="hidden" name="item_name" value="Chicken kabab">
                    <input type="hidden" name="price" value="60">
                    </div>
            </div>
            <div class="col-2 mt-4" style="margin-left:0px;">
            
            <form action="header.php" method="POST">    
            <div class="card" id="item1" style="margin-left:0px;"> 
                       <h5 style="margin-left:15px;" class="title"><img src="pexels-dana-tentis-262959.jpg" width="140" height="160"><br>&nbsp;&nbsp;&nbsp;Fish Fry</h5><b style="margin-left:30px;color: rgb(246, 8, 8);">Cost: ₹150</b>
                    <br><br><button type="submit" class="rounded-pill" style="background-color: yellow;" name="Add_To_Cart">ADD TO CART</button>
                    <input type="hidden" name="item_name" value="Fish Fry">
                    <input type="hidden" name="price" value="150">

                </div>
    </form>
            </div>
            <div class="col-2 mt-4" style="margin-left:0px;">
            
            <form action="header.php" method="POST">    
            <div class="card" id="item1" style="margin-left:0px;"> 
                       <h5 style="margin-left:15px;" class="title"><img src="egg_puff.jpg" width="140" height="160"><br>&nbsp;&nbsp;&nbsp;Egg Puff</h5><b style="margin-left:30px;color: rgb(246, 8, 8);">Cost: ₹20</b>

                    <br><br><button type="submit" class="rounded-pill" style="background-color: rgb(255, 225, 0);" name="Add_To_Cart">ADD TO CART</button>
                    <input type="hidden" name="item_name" value="Egg puff">
                    <input type="hidden" name="price" value="20">
                    </div>
            </form>
            </div>
            <div class="col-2 mt-4" style="margin-left:0px;">
            
            <form action="header.php" method="POST">    
            <div class="card" id="item1" style="margin-left:0px;"> 
                       <h5 style="margin-left:15px;" class="title"><img src="cicken.jpg" width="140" height="160"><br>&nbsp;&nbsp;Chicken Fry &nbsp;&nbsp;Piece</h5><b style="margin-left:30px;color: rgb(246, 8, 8);">Cost: ₹130</b>
                    <br><br><button type="submit" class="rounded-pill" style="background-color: yellow;" name="Add_To_Cart">ADD TO CART</button>
                    <input type="hidden" name="item_name" value="Chicken fry piece">
                    <input type="hidden" name="price" value="130">

                </div></form>
            </div>
            <div class="col-2 mt-4" style="margin-left:0px;">
            
            <form action="header.php" method="POST">    
            <div class="card" id="item1" style="margin-left:0px;"> 
                       <h5 style="margin-left:15px;" class="title"><img src="cicken_puff.jpeg" width="140" height="160"><br>&nbsp;&nbsp;&nbsp;Chicken Puff</h5><b style="margin-left:30px;color: rgb(246, 8, 8);">Cost: ₹30</b>

                    <br><br><button type="submit" class="rounded-pill" style="background-color: yellow;" name="Add_To_Cart">ADD TO CART</button>
                    <input type="hidden" name="item_name" value="Chicken puff">
                    <input type="hidden" name="price" value="30">
                    </div>
    </form>
            </div>
        </div>
        <p style="margin-left:150px;">--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------</p>
        <h3 style="margin-left:150px;" class="mt-5">Veg-items:</h3>

        <div class="row mt-5" style="margin-left: 170px;">
            <div class="col-2">
            
            <form action="header.php" method="POST">    
            <div class="card" id="item1"> 
                       <h5 style="margin-left:15px;" class="title"><img src="pexels-rajesh-tp-1633578.jpg" width="140" height="160"><br>&nbsp;&nbsp;&nbsp;Veg Burger</h5><b style="margin-left:30px;color: rgb(246, 8, 8);">Cost: ₹100</b>
                    <br><br><button type="submit" class="rounded-pill" style="background-color: yellow;" name="Add_To_Cart">ADD TO CART</button>
                    <input type="hidden" name="item_name" value="Veg Burger">
                    <input type="hidden" name="price" value="100">

                </div>
            </form>
            </div>
            <div class="col-2" style="margin-left:0px;">
            
            <form action="header.php" method="POST">    
            <div class="card" id="item1"> 
                       <h5 style="margin-left:15px;" class="title"><img src="pizza.jpeg" width="140" height="160"><br>&nbsp;&nbsp;&nbsp;PIZZA</h5><b style="margin-left:30px;color: rgb(246, 8, 8);">Cost: ₹140</b>
                    <br><br><button type="submit" class="rounded-pill" style="background-color: yellow;" name="Add_To_Cart">ADD TO CART</button>
                    <input type="hidden" name="item_name" value="PIZZA">
                    <input type="hidden" name="price" value="140">

                </div>
            </form>
            </div>
            <div class="col-2" style="margin-left:0px;">
            
            <form action="header.php" method="POST">    
            <div class="card" id="item1"> 
                       <h5 style="margin-left:15px;" class="title"><img src="pexels-lisa-fotios-1279330.jpg" width="140" height="160px"><br>Veg Noodles</h5><b style="margin-left:30px;color: rgb(246, 8, 8);">Cost: ₹50</b>

                    <br><br><button type="submit" class="rounded-pill" style="background-color: yellow;" name="Add_To_Cart">ADD TO CART</button>
                    <input type="hidden" name="item_name" value="Veg Noodles">
                    <input type="hidden" name="price" value="50">
                    </div>
            </form>
            </div>
            <div class="col-2" style="margin-left:0px;">
            
            <form action="header.php" method="POST">    
            <div class="card" id="item1" style="margin-left:0px;"> 
                       <h5 style="margin-left:15px;" class="title"><img src="gobi rice.jpg" width="140" height="160"><br>&nbsp;&nbsp;&nbsp;Gobi Rice</h5><b style="margin-left:30px;color: rgb(246, 8, 8);">Cost: ₹80</b>

                    <br><br><button type="submit" class="rounded-pill" style="background-color: yellow;" name="Add_To_Cart">ADD TO CART</button>
                    <input type="hidden" name="item_name" value="Gobi Rice">
                    <input type="hidden" name="price" value="80">
                    </div>
            </form>
            </div>
            <div class="col-2" style="margin-left:0px;">
            
            <form action="header.php" method="POST">    
            <div class="card" id="item1" style="margin-left:0px;"> 
                       <h5 style="margin-left:15px;" class="title"><img src="veg.jpeg" width="140" height="160"><br>&nbsp;&nbsp;Mushroom &nbsp;&nbsp;Biryani</h5><b style="margin-left:30px;color: rgb(246, 8, 8);">Cost: ₹200</b>
                    <br><br><button type="submit" class="rounded-pill" style="background-color: yellow;" name="Add_To_Cart">ADD TO CART</button>
                    <input type="hidden" name="item_name" value="Mushroom Biryani">
                    <input type="hidden" name="price" value="200">

                </div>
            </form>
            </div>
            <div class="col-2">

            </div>
            <div class="col-2 mt-4" style="margin-left:0px;">
            
            <form action="header.php" method="POST">    
            <div class="card" id="item1" style="margin-left:0px;"> 
                       <h5 style="margin-left:15px;" class="title"><img src="chapati.jpeg" width="140" height="160"><br>&nbsp;&nbsp;&nbsp;Chapati</h5><b style="margin-left:30px;color: rgb(246, 8, 8);">Cost: ₹30</b>

                    <br><br><button type="submit" class="rounded-pill" style="background-color: yellow;" name="Add_To_Cart">ADD TO CART</button>
                    <input type="hidden" name="item_name" value="Chapati">
                    <input type="hidden" name="price" value="30">
                    </div>
    </form>
            </div>
            <div class="col-2 mt-4" style="margin-left:0px;">
            
            <form action="header.php" method="POST">    
            <div class="card" id="item1" style="margin-left:0px;"> 
                       <h5 style="margin-left:15px;" class="title"><img src="mini.jpeg" width="140" height="160"><br>&nbsp;&nbsp;&nbsp;Mini Meals</h5><b style="margin-left:30px;color: rgb(246, 8, 8);">Cost: ₹65</b>

                    <br><br><button type="submit" class="rounded-pill" style="background-color: yellow;" name="Add_To_Cart">ADD TO CART</button>
                    <input type="hidden" name="item_name" value="Mini Meals">
                    <input type="hidden" name="price" value="65">
                    </div>
    </form>
            </div>
            <div class="col-2 mt-4" style="margin-left:0px;">
            
            <form action="header.php" method="POST">    
            <div class="card" id="item1" style="margin-left:0px;"> 
                       <h5 style="margin-left:15px;" class="title"><img src="pulihora.jpeg" width="140" height="160"><br>&nbsp;&nbsp;&nbsp;Pulihora</h5><b style="margin-left:30px;color: rgb(246, 8, 8);">Cost: ₹50</b>

                    <br><br><button type="submit" class="rounded-pill" style="background-color: yellow;" name="Add_To_Cart">ADD TO CART</button>
                    <input type="hidden" name="item_name" value="Pulihora">
                    <input type="hidden" name="price" value="50">
                    </div>
    </form>
            </div>
            <div class="col-2 mt-4" style="margin-left:0px;">
            
            <form action="header.php" method="POST">    
            <div class="card" id="item1" style="margin-left:0px;"> 
                       <h5 style="margin-left:15px;" class="title"><img src="parota.jpeg" width="140" height="160"><br>&nbsp;&nbsp;&nbsp;Parota</h5><b style="margin-left:30px;color: rgb(246, 8, 8);">Cost: ₹30</b>

                    <br><br><button type="submit" class="rounded-pill" style="background-color: yellow;" name="Add_To_Cart">ADD TO CART</button>
                    <input type="hidden" name="item_name" value="Parota">
                    <input type="hidden" name="price" value="30">
                    </div>
    </form>
            </div>
            <div class="col-2 mt-4" style="margin-left:0px;">
            
            <form action="header.php" method="POST">    
            <div class="card" id="item1" style="margin-left:0px;"> 
                       <h5 style="margin-left:15px;" class="title"><img src="gobi.jpeg" width="140" height="160"><br>&nbsp;&nbsp;&nbsp;Gobi</h5><b style="margin-left:30px;color: rgb(246, 8, 8);">Cost: ₹70</b>

                    <br><br><button type="submit" class="rounded-pill" style="background-color: yellow;" name="Add_To_Cart">ADD TO CART</button>
                    <input type="hidden" name="item_name" value="Gobi">
                    <input type="hidden" name="price" value="70">
                    </div>
    </form>
            </div>
        </div>
        <p style="margin-left:150px;">--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------</p>
        <h3 style="margin-left:150px;" class="mt-5">Cool Drinks and BreakFast Items:</h3>

        <div class="row mt-5" style="margin-left: 170px;">
            <div class="col-2">
            
            <form action="header.php" method="POST">    
            <div class="card" id="item1"> 
                       <h5 style="margin-left:15px;" class="title"><img src="vada.jpeg" width="140" height="160"><br>&nbsp;&nbsp;&nbsp;VADA</h5><b style="margin-left:30px;color: rgb(246, 8, 8);">Cost: ₹25</b>

                    <br><br><button type="submit" class="rounded-pill" style="background-color: yellow;" name="Add_To_Cart">ADD TO CART</button>
                    <input type="hidden" name="item_name" value="Vada">
                    <input type="hidden" name="price" value="25">
                    </div>
            </form>
            </div>
            <div class="col-2" style="margin-left:0px;">
            
            <form action="header.php" method="POST">    
            <div class="card" id="item1"> 
                       <h5 style="margin-left:15px;" class="title"><img src="dosa.jpeg" width="140" height="160"><br>&nbsp;&nbsp;&nbsp;DOSA</h5><b style="margin-left:30px;color: rgb(246, 8, 8);">Cost: ₹25</b>

                    <br><br><button type="submit" class="rounded-pill" style="background-color: yellow;" name="Add_To_Cart">ADD TO CART</button>
                    <input type="hidden" name="item_name" value="Dosa">
                    <input type="hidden" name="price" value="25">
                    </div>
            </form>
            </div>
            <div class="col-2" style="margin-left:0px;">
            
            <form action="header.php" method="POST">    
            <div class="card" id="item1"> 
                       <h5 style="margin-left:15px;" class="title"><img src="idly.jpeg" width="140" height="160px"><br>IDLY</h5><b style="margin-left:30px;color: rgb(246, 8, 8);">Cost: ₹20</b>

                    <br><br><button type="submit" class="rounded-pill" style="background-color: yellow;" name="Add_To_Cart">ADD TO CART</button>
                    <input type="hidden" name="item_name" value="IDLY">
                    <input type="hidden" name="price" value="20">
                    </div>
            </form>
            </div>
            <div class="col-2" style="margin-left:0px;">
            
            <form action="header.php" method="POST">    
            <div class="card" id="item1" style="margin-left:0px;"> 
                       <h5 style="margin-left:15px;" class="title"><img src="chapati.jpeg" width="140" height="160"><br>&nbsp;&nbsp;&nbsp;Butternaan</h5><b style="margin-left:30px;color: rgb(246, 8, 8);">Cost: ₹35</b>

                    <br><br><button type="submit" class="rounded-pill" style="background-color: yellow;" name="Add_To_Cart">ADD TO CART</button>
                    <input type="hidden" name="item_name" value="Butternaan">
                    <input type="hidden" name="price" value="35">
                    </div>
            </form>
            </div>
            <div class="col-2" style="margin-left:0px;">
            
            <form action="header.php" method="POST">    
            <div class="card" id="item1" style="margin-left:0px;"> 
                       <h5 style="margin-left:15px;" class="title"><img src="puri.jpeg" width="140" height="160"><br>&nbsp;&nbsp;&nbsp;Puri</h5><b style="margin-left:30px;color: rgb(246, 8, 8);">Cost: ₹20</b>

                    <br><br><button type="submit" class="rounded-pill" style="background-color: yellow;" name="Add_To_Cart">ADD TO CART</button>
                    <input type="hidden" name="item_name" value="Puri">
                    <input type="hidden" name="price" value="20">
                    </div>
            </form>
            </div>
            <div class="col-2">

            </div>
            <div class="col-2 mt-4" style="margin-left:0px;">
            
            <form action="header.php" method="POST">    
            <div class="card" id="item1" style="margin-left:0px;"> 
                       <h5 style="margin-left:15px;" class="title"><img src="sting.jpeg" width="140" height="160"><br>&nbsp;&nbsp;&nbsp;STING </h5><b style="margin-left:30px;color: rgb(246, 8, 8);">Cost: ₹20</b>

                    <br><br><button type="submit" class="rounded-pill" style="background-color: yellow;" name="Add_To_Cart">ADD TO CART</button>
                    <input type="hidden" name="item_name" value="Sting">
                    <input type="hidden" name="price" value="20">
                    </div></form>
            </div>
            <div class="col-2 mt-4" style="margin-left:0px;">
            
            <form action="header.php" method="POST">    
            <div class="card" id="item1" style="margin-left:0px;"> 
                       <h5 style="margin-left:15px;" class="title"><img src="sprite.jpeg" width="140" height="160"><br>&nbsp;&nbsp;&nbsp;Sprite</h5><b style="margin-left:30px;color: rgb(246, 8, 8);">Cost: ₹70</b>

                    <br><br><button type="submit" class="rounded-pill" style="background-color: yellow;" name="Add_To_Cart">ADD TO CART</button>
                    <input type="hidden" name="item_name" value="Sprite">
                    <input type="hidden" name="price" value="70">
                    </div></form>
            </div>
            <div class="col-2 mt-4" style="margin-left:0px;">
            
            <form action="header.php" method="POST">    
            <div class="card" id="item1" style="margin-left:0px;"> 
                       <h5 style="margin-left:15px;" class="title"><img src="thumsup.jpeg" width="140" height="160"><br>&nbsp;&nbsp;&nbsp;Thumsup</h5><b style="margin-left:30px;color: rgb(246, 8, 8);">Cost: ₹70</b>

                    <br><br><button type="submit" class="rounded-pill" style="background-color: yellow;" name="Add_To_Cart">ADD TO CART</button>
                    <input type="hidden" name="item_name" value="Thumsup">
                    <input type="hidden" name="price" value="70">
                    </div></form>
            </div>
            <div class="col-2 mt-4" style="margin-left:0px;">
            
            <form action="header.php" method="POST">    
            <div class="card" id="item1" style="margin-left:0px;"> 
                       <h5 style="margin-left:15px;" class="title"><img src="orange.jpeg" width="140" height="160"><br>&nbsp;&nbsp;&nbsp;Orange Juice</h5><b style="margin-left:30px;color: rgb(246, 8, 8);">Cost: ₹50</b>

                    <br><br><button type="submit" class="rounded-pill" style="background-color: yellow;" name="Add_To_Cart">ADD TO CART</button>
                    <input type="hidden" name="item_name" value="Orange Juice">
                    <input type="hidden" name="price" value="50">
                    </div></form>
            </div>
            <div class="col-2 mt-4" style="margin-left:0px;">
            
            <form action="header.php" method="POST">    
            <div class="card" id="item1" style="margin-left:0px;"> 
                       <h5 style="margin-left:15px;" class="title"><img src="sraw.jpeg" width="140" height="160"><br>&nbsp;&nbsp;Strawberry &nbsp;&nbsp;Juice</h5><b style="margin-left:30px;color: rgb(246, 8, 8);">Cost: ₹80</b>

                    <br><br><button type="submit" class="rounded-pill" style="background-color: yellow;" name="Add_To_Cart">ADD TO CART</button>
                    <input type="hidden" name="item_name" value="Strawberry juice">
                    <input type="hidden" name="price" value="80">
                    </div></form>
            </div>
        </div>
           
                
                        
    
            
        <div>

        </div>
        
        
    </body>
</html>