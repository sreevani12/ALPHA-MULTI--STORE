<?php
session_start();
?>

<?php

$_SESSION['email']=$_POST['email'];
$_SESSION['pass']=$_POST['password'];
include "registerdb.php";
if($connect)
{
    echo "yes";
}
else
{
    echo "no";
}
 $name=$_POST['uname'];
 $pass=$_POST['password'];

 $mob=$_POST['ps'];
 $email=$_POST['email'];
 


 $query="select *from AMSLOGIN;";

    echo 'error';

$que=mysqli_query($connect,$query);
if(mysqli_num_rows($que)){
    echo "bgwkjnbkjfnklNFLK";


while($row=mysqli_fetch_assoc($que))

    {
        if($row['GMAILID_ID']==$email)
        {
            if($row['PASSWORD']==$pass)
            {
                echo "<script>
                alert('ALREADY REGISTER GOTO  LOGIN PAGE');
                window.location.href='veg123.php';
                </script>";
                return false;
            }
        }
    }

}

$insert="insert into AMSLOG values('$name',$mob,'$email','$pass');";
if(mysqli_query($connect,$insert))
{
    echo "inserted";
    header("location:veg123.php");
    exit();
    return false;
}

else{
    echo "error";
}
?>